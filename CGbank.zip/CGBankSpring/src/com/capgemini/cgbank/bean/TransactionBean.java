package com.capgemini.cgbank.bean;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="Transactions")
public class TransactionBean {
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "accountId")
	
	private AccMasterBean account;
	@Id
	@Column(name="transactionId")
	private int transId;
	@Column(name="transactiondescription")
	private String transDescription;
	@Column(name="dateoftransacrion")
	private Date dateOfTrans;
	@Column(name="transactiontype")
	private String transType;
	@Column(name="transactionamount")
	private double transactionAmount;
	public TransactionBean() {
		super();
	}
	
	
	public int getTransId() {
		return transId;
	}
	public void setTransId(int transId) {
		this.transId = transId;
	}
	public String getTransDescription() {
		return transDescription;
	}
	public void setTransDescription(String transDescription) {
		this.transDescription = transDescription;
	}
	public Date getDateOfTrans() {
		return dateOfTrans;
	}
	public void setDateOfTrans(Date dateOfTrans) {
		this.dateOfTrans = dateOfTrans;
	}
	public String getTransType() {
		return transType;
	}
	public void setTransType(String transType) {
		this.transType = transType;
	}
	public double getTransactionAmount() {
		return transactionAmount;
	}
	public void setTransactionAmount(double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}


	public AccMasterBean getAccount() {
		return account;
	}


	public void setAccount(AccMasterBean account) {
		this.account = account;
	}


	public TransactionBean(AccMasterBean account, int transId,
			String transDescription, Date dateOfTrans, String transType,
			double transactionAmount) {
		super();
		this.account = account;
		this.transId = transId;
		this.transDescription = transDescription;
		this.dateOfTrans = dateOfTrans;
		this.transType = transType;
		this.transactionAmount = transactionAmount;
	}


	@Override
	public String toString() {
		return "TransactionBean [account=" + account + ", transId=" + transId
				+ ", transDescription=" + transDescription + ", dateOfTrans="
				+ dateOfTrans + ", transType=" + transType
				+ ", transactionAmount=" + transactionAmount + "]";
	}
	
	
	
	

}
