package com.capgemini.cgbank.bean;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="payee")

public class PayeeBean {
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "accountId")
	private AccMasterBean account;
	@Id
	@Column(name="payeeId")
	private int payeeAccId;
	@Column(name="nickname")
	private String nickName;
	
	public int getPayeeAccId() {
		return payeeAccId;
	}
	public void setPayeeAccId(int payeeAccId) {
		this.payeeAccId = payeeAccId;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	
	public PayeeBean() {
		super();
	}
	public AccMasterBean getAccount() {
		return account;
	}
	public void setAccount(AccMasterBean account) {
		this.account = account;
	}
	public PayeeBean(AccMasterBean account, int payeeAccId, String nickName) {
		super();
		this.account = account;
		this.payeeAccId = payeeAccId;
		this.nickName = nickName;
	}
	@Override
	public String toString() {
		return "PayeeBean [account=" + account + ", payeeAccId=" + payeeAccId
				+ ", nickName=" + nickName + "]";
	}
	
	
}
