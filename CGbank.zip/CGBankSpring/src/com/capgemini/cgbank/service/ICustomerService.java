package com.capgemini.cgbank.service;

import com.capgemini.cgbank.bean.UserTable;
import com.capgemini.cgbank.exception.BankException;

public interface ICustomerService {
	public UserTable getValidUser(int userId,String password)throws BankException;

}
