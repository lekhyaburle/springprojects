package com.capgemini.cgbank.dao;

public interface IQueryMapperCustomer {

	
	public static final String viewUser="from UserTable where userId=? and password=?";
}
